#!/usr/bin/env python

import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('tkAgg', force=True)
import matplotlib.pyplot as plt
from scipy.io import wavfile
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import time

# ------------------------------------------------------------------ 
#                       MAIN CODE
# ------------------------------------------------------------------

if __name__ == "__main__":

    # read wav_file
    Fs, data = wavfile.read('./noise.wav')
    data = data/np.amax(data)

    I_data = data[:,0]
    Q_data = data[:,1]

    # Compute envelope from IQ data
    x = np.abs(I_data + 1j*Q_data)
    # substract DC
    x = x - np.average(x)

    # autocorrelation
    Ncorr = signal.correlate(x, x, mode='same')
    # Normalise
    #Ncorr = Ncorr/np.amax(Ncorr)

    # ------------------------------------------------------------------ 
    #                       PLOT RESULTS
    # ------------------------------------------------------------------

    # --- Plot results

    SMALL_SIZE = 12
    MEDIUM_SIZE = 14
    BIGGER_SIZE = 16

    plt.rc('font', size=SMALL_SIZE)                 # controls default text sizes
    plt.rc('axes', titlesize=MEDIUM_SIZE)           # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)           # fontsize of the x and y labels
    plt.rc('xtick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('ytick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('legend', fontsize=SMALL_SIZE)           # legend fontsize
    plt.rc('figure', titlesize=BIGGER_SIZE)         # fontsize of the figure title
    plt.rc('lines', linewidth=1.5, markersize=6)    # line parameters

    fig, (ax1, ax2) = plt.subplots(2, 2, sharex=False)
    mng = plt.get_current_fig_manager()
    mng.window.state('zoomed')

    #--------------------------- AX1 -----------------------------------
    t = np.arange(len(x))/Fs*1000
    ax1[0].plot(t, x, label='Noise autocorrelation')
    ax1[0].set_xlabel('time (ms)')
    ax1[0].set_ylabel('Amplitude')
    ax1[0].set_title('Noise envelope', c='blue')
    #--------------------------- AX2 -----------------------------------
    
    lags = np.arange(-len(Ncorr)/2, len(Ncorr)/2, step=1)/Fs*1000 # ms
    ax2[0].plot(lags, Ncorr, label='Noise autocorrelation')
    ax2[0].set_xlabel('Time lag (ms)')
    ax2[0].set_ylabel('Amplitude')
    ax2[0].set_title('Noise autocorrelation', c='blue')

    ax2[1].plot(lags[int(len(Ncorr)/2-50):int(len(Ncorr)/2+50)], Ncorr[int(len(Ncorr)/2-50):int(len(Ncorr)/2+50)], '-o', label='Noise autocorrelation zoom')
    ax2[1].set_xlabel('Time lag (ms)')
    ax2[1].set_ylabel('Amplitude')
    ax2[1].set_title('Noise autocorrelation zoom', c='blue')

    #-------------------------------------------------------------------

    fig.tight_layout()
    fig.subplots_adjust(wspace=0.1, hspace=0.4, bottom=0.08, top=0.92, left=0.06, right=0.95)

    plt.show()


