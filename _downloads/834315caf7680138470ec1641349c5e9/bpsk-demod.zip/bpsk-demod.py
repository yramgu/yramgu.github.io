#!/usr/bin/env python

"""
MIT License

Copyright (c) 2022 Yannish RAMGULAM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np
from scipy.signal import correlate
from scipy.io import wavfile
import logging

import matplotlib
matplotlib.use('tkAgg', force=True)
import matplotlib.pyplot as plt

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
warnings.simplefilter(action='ignore', category=RuntimeWarning)

from functions import *

# ------------------------------------------------------------------ 
#                       INPUTS
# ------------------------------------------------------------------

EXPECTED_BAUDRATE = 100
FILENAME = "bpsk_waveform.wav"

SYNC_WORD = [0xF9, 0xA8]
PAYLOAD_SIZE = 8
CRC_SIZE = 2
CRC_POLYNOMIAL = (16, 12, 5)
CRC_SEED = 0x5555

# ------------------------------------------------------------------ 
#                       MAIN CODE
# ------------------------------------------------------------------

if __name__ == "__main__":

    # Logging configuration
    logging.basicConfig(format='%(asctime)s\t[%(levelname)s]\t%(message)s',datefmt='%d/%m/%Y %H:%M:%S', level=logging.INFO)
    logger = logging.getLogger()

    # read wav_file
    Fs, data = wavfile.read('./' + FILENAME)
    logger.info("Sampling rate = %d Hz"%Fs)
    sps = int(Fs/EXPECTED_BAUDRATE)
    logger.info("Samples per symbol = %d sps"%sps)

    # normalise
    data = data / np.amax(data)

    # extract I and Q from interleaved WAV data
    I = data[:,0]
    Q = data[:,1]

    # rebuild complex signal
    x = I + 1j*Q

    # calculate FFT
    fft = 20*np.log10(np.abs(np.fft.fftshift(np.fft.fft(x)))/len(x))
    freqs = np.fft.fftshift(np.fft.fftfreq(len(x), d=1/Fs))/1000 # freqs expressed in kHz

    # coarse frequency offset estimation
    # get peak of fft and rotate back to baseband
    coarse_freq_offset = freqs[np.argmax(fft)] * 1000 # *1000 is to put back in Hz
    logger.info("coarse frequency offset = %d Hz"%coarse_freq_offset)
    # build time vector
    t = np.arange(len(x))/Fs
    # rotate
    x = x * np.exp(-1j * 2*np.pi * coarse_freq_offset * t)

    # calculate FFT of the rotated signal
    fftr = 20*np.log10(np.abs(np.fft.fftshift(np.fft.fft(x)))/len(x))

    # Go through the costas loop to demodulate the phase
    # this will also perform fine frequency offset correction
    out, phase_estimate, freq_estimate = costas_loop(x, Fs)

    # -- synchronise --
    # amplitude needs to be 1 pk-pk (+/-0.5) else loop won't converge
    # so we divide the baseband data currently ranging from (+/-1) by 2
    # this could be improved but I'm lazy
    data = np.real(out)/2 

    # go through clock recovery
    out_synced, clock = timing_recovery(data, sps, Kp=-1*sps/4) # put Kp = -3*sps/4 for faster lock

    # Now that we have time lock, calculate EVM for each symbol
    evm = calculate_evm_bpsk(out[clock])

    # extract bitstream, format as NRZ
    bits = np.asarray([1 if x > 0 else -1 for x in out_synced])

    # apply reverse differential encoding
    decoded_bits = []
    previous_bit = 0
    for bit in bits:
        if bit == previous_bit: decoded_bits.append(1)
        else:
            previous_bit = bit
            decoded_bits.append(-1)
    bits = np.asarray(decoded_bits)

    # Find the sync word
    # transform sync word into binary array
    syncWordBin = hexTobinary(SYNC_WORD, NRZ=True)
    # correlate bitstream with sync word
    correlation = np.abs(correlate(bits, syncWordBin, mode='same'))
    # find index of max correlation
    maxCorr = np.argmax(correlation)
    # find beginning of sync word in bitstream
    syncIndex = int(maxCorr - len(syncWordBin)/2)
    logger.info("Sync Word likely found starting at index = %d"%syncIndex)

    # transform bistream from NRZ to RZ for convenience/easier reading
    bits = [1 if x==1 else 0 for x in bits]

    # get the payload start index
    payloadStartIndex = int(maxCorr + len(syncWordBin)/2)
    payload = bits[payloadStartIndex:payloadStartIndex + PAYLOAD_SIZE*8]

    logger.info("Payload = {}".format(' '.join(map(str, payload))))

    # check the CRC
    CRCstart = payloadStartIndex + PAYLOAD_SIZE*8 + 1
    # retrieve CRC bits from bitstream
    crc_candidate = bits[CRCstart:CRCstart + CRC_SIZE*8]
    # recalculate crc from payload
    crc = CalculateCRC(payload, seed=CRC_SEED, poly=CRC_POLYNOMIAL)

    logger.info("CRC candidate  = {}".format(' '.join(map(str, crc_candidate))))
    logger.info("CRC calculated = {}".format(' '.join(map(str, crc))))

    # compare calculated and received CRC
    if crc_candidate == crc:
        logger.info("calculated CRC matches the received CRC")
    else:
        logger.info("calculated and received CRC do not match")

    # decode the payload
    decoded_payload = decode_payload(payload, PAYLOAD_SIZE)
    logger.info("decoded payload = %s"%decoded_payload)


    # ------------------------------------------------------------------ 
    #                       PLOT RESULTS
    # ------------------------------------------------------------------

    # --- Plot results

    SMALL_SIZE = 12
    MEDIUM_SIZE = 14
    BIGGER_SIZE = 16

    plt.rc('font', size=SMALL_SIZE)                 # controls default text sizes
    plt.rc('axes', titlesize=MEDIUM_SIZE)           # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)           # fontsize of the x and y labels
    plt.rc('xtick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('ytick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('legend', fontsize=SMALL_SIZE)           # legend fontsize
    plt.rc('figure', titlesize=BIGGER_SIZE)         # fontsize of the figure title
    plt.rc('lines', linewidth=1.5, markersize=6)    # line parameters

    fig2, (ax3, ax4) = plt.subplots(2, 2, sharex=False)
    mng = plt.get_current_fig_manager()
    mng.window.state('zoomed')

    fig, (ax1, ax2) = plt.subplots(2, 2, sharex=False)
    mng = plt.get_current_fig_manager()
    mng.window.state('zoomed')

    #--------------------------- AX1 -----------------------------------

    t = np.arange(len(x))/Fs*1000
    ax1[0].plot(t, I, label='I')
    ax1[0].plot(t, Q + 2.5, label='Q')
    ax1[0].set_xlabel('time (ms)')
    ax1[0].set_ylabel('Amplitude')
    ax1[0].set_title('IQ data', c='blue')
    ax1[0].set_ylim(top=4.5)
    ax1[0].legend(ncol=2)

    ax1[1].plot(freqs, fft, label='fft')
    ax1[1].plot(freqs, fftr, label='rotated fft')
    ax1[1].set_xlabel('frequency (kHz)')
    ax1[1].set_ylabel('Amplitude')
    ax1[1].set_title('FFT', c='blue')
    ax1[1].legend(ncol=2)

    #--------------------------- AX2 -----------------------------------
  
    ax2[0].plot(t, np.real(x), label='I')
    ax2[0].plot(t, np.imag(x) + 2.5, label='Q')
    ax2[0].set_xlabel('Time (ms')
    ax2[0].set_ylabel('Amplitude')
    ax2[0].set_title('rotated IQ', c='blue')
    ax2[0].set_ylim(top=4.5)
    ax2[0].legend(ncol=2)
    
    ax2[1].plot(t, np.real(out), label='I')
    ax2[1].plot(t, np.imag(out), label='Q')
    ax2[1].set_xlabel('Time (ms)')
    ax2[1].set_ylabel('Amplitude')
    ax2[1].set_title('Costas loop output', c='blue')
    ax2[1].set_ylim(top=1.5)
    ax2[1].legend(ncol=2)
    
    fig.tight_layout()
    fig.subplots_adjust(wspace=0.15, hspace=0.4, bottom=0.08, top=0.92, left=0.05, right=0.95)

    #-------------------------------------------------------------------

    ax3[0].plot(t, np.real(out), label='raw data')
    ax3[0].plot(np.int32(clock/Fs*1000), np.real(out)[clock], 'ro', label='synced data')
    ax3[0].set_xlabel('Time (ms)')
    ax3[0].set_ylabel('Amplitude')
    ax3[0].set_title('baseband data', c='blue')
    ax3[0].set_ylim(top=1.5)
    ax3[0].legend(ncol=2)

    ax3[1].axvline(0, c='black')
    ax3[1].axhline(0, c='black')
    circle = plt.Circle((0, 0), 1, color='b', fill=False)
    ax3[1].add_patch(circle)
    ax3[1].plot(np.real(out)[clock], np.imag(out)[clock], 'ro', label='')
    #ax3[1].plot(I, Q, 'ro', label='', markersize=2)
    ax3[1].set_xlabel('I')
    ax3[1].set_ylabel('Q')
    ax3[1].set_title('Constellation', c='blue')
    ax3[1].set_xlim(left=-1.2, right = 1.2)
    ax3[1].set_ylim(top=1.2, bottom = -1.2)
    ax3[1].axis('scaled')

    ax4[0].plot(20*np.log10(evm), '-o')
    ax4[0].set_xlabel('Symbol')
    ax4[0].set_ylabel('EVM (dB)')
    ax4[0].set_title('EVM per symbol', c='blue')

    ax4[1].plot(correlation)
    ax4[1].plot(maxCorr, correlation[maxCorr], 'ro')
    ax4[1].set_xlabel('Sync Word')
    ax4[1].set_ylabel('Correlation maximum')
    ax4[1].set_title('Sync Word search', c='blue')

    fig2.tight_layout()
    fig2.subplots_adjust(wspace=0.15, hspace=0.4, bottom=0.08, top=0.92, left=0.05, right=0.95)


    plt.show()