"""
MIT License

Copyright (c) 2022 Yannish RAMGULAM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np
from scipy.signal import correlate
import logging
import wave

#========================================================================================
#========================================================================================

def record_wav(I, Q, clockRate, mainpath='./WAV/', filename='',):

  """
  Record IQ data in a WAV file

    I, Q: ndarray
      IQ data, float numbers between [None, +1]

    clockRate: integer
      sampling rate used by generator that will play the waveform, in Hz

    mainpath: string
      path to save file to

    filename: string
      file name
  """

  logging.info('Saving waveform to %s%s.wav\n'%(mainpath,filename))

  wavefile = wave.open(mainpath + filename + '.wav', mode='wb')

  wavefile.setnchannels(2)
  wavefile.setsampwidth(2)
  wavefile.setframerate(np.int32(clockRate))
  wavdata = np.empty(len(I)*2)
  wavdata[0::2] = I
  wavdata[1::2] = Q
  wavefile.writeframes(np.int16(wavdata*(2**15-1))) 

  wavefile.close()
  
#----------------------------------------------------------------------------------------

def costas_loop(x, Fs=10000, damping=0.707, loop_bw=1, coarse_freq_offset=0):

  """
  Costas loop

    x: ndarray
      input waveform, complex signal (IQ data)
      format I + jQ

    Fs: integer
      waveform sampling rate

    damping: float
      Loop damping factor

    loop_bw: integer
      loop bandwidth, in percent of the sampling rate
      value should be between 1 and 5 (%)

    coarse_freq_offset: integer
      coarse frequency offset estimate, in Hz
  """
    
  N = len(x)

  # NCO gain
  K0 = 1 
  # phase detector gain
  KD = 1

  # loop bw between 1% and 5% of Fs
  Bn = loop_bw/100 * Fs 

  # coefficients of the loop filter
  KP = 1/(KD*K0) * (4*damping)/(damping + 1/(4*damping)) * Bn/Fs
  KI = 1/(KD*K0) * 4 / (damping + 1/(4*damping))**2 * (Bn/Fs)**2
  
  # variables inits
  e_D = 0 # phase-error input to loop filter
  e_F = 0 # loop filter output
  out = np.zeros(N, dtype=np.complex128) # output signal
  freq_estimate = np.zeros(N)
  phase_estimate = np.zeros(N) # phase accumulator, control signal for NCO
  integrator_out = 0

  # coarse frequency correction
  timeVector = np.arange(N)/Fs
  rotator = 2*np.pi * coarse_freq_offset * timeVector
  
  for n in range(0, N-1):

      # downconvert to baseband
      out[n] = x[n] * np.exp(-1j * (rotator[n] + phase_estimate[n]))

      # no need for LPF on I and Q branches as we  already downconverted to baseband
      e_D = np.real(out[n]) * np.imag(out[n])

      # loop filter
      integrator_out += KI * e_D
      freq_estimate[n] = integrator_out * Fs/(2*np.pi) # this is only for debug
      e_F = integrator_out + KP * e_D

      # NCO
      phase_estimate[n+1] = phase_estimate[n] + K0 * e_F

  return out, phase_estimate, freq_estimate

#----------------------------------------------------------------------------------------

def timing_recovery(data, sps, Kp):

    """
    !!!!! Amplitude of signal HAS to be 1 (or +/-0.5)

    data: ndarray
      data that needs to be synced

    sps: integer
      samples per symbols

    Kp: negative integer
      loop gain
      Good values: -sps/2, -3*sps/4
    """

    initial_index   = 0

    clock           = []
    synced_data     = []
    
    error           = 0
    index           = 0
    epsilon         = 0

    while (initial_index + index*sps + epsilon) < len(data) - sps :

        # gardner formula
        error = (data[int(initial_index + (index*sps) + epsilon)] - data[int(initial_index + (index-1)*sps + epsilon)]) * data[int(initial_index + index*sps - sps/2 + epsilon)] 

        epsilon += error*Kp

        clock.append(int(initial_index + (index*sps) + epsilon))
        synced_data.append(data[int(initial_index + (index*sps) + epsilon)])

        index += 1
    
    return np.asarray(synced_data), np.asarray(clock)
  
#----------------------------------------------------------------------------------------

def calculate_evm_bpsk(x):

    """
    x: ndarray
      complex values for each symbol
      x has a rate of 1sps
    """

    evm = []

    for sample in x:
      Ierr = 1 - np.abs(np.real(sample))
      Qerr = np.abs(np.imag(sample))
      evm.append(np.sqrt(Ierr**2 + Qerr**2))

    return evm

#----------------------------------------------------------------------------------------

def hexTobinary(data, BitOrder='MSB', NRZ=False):
  
  """
  Convert  data to binary representation
    - data = input data in decimal
    - BitOrder = MSB first or LSB first

    returns bits 
  """

  binary = [] # array of decimal 0 and 1
  for item in data:
    for i in range(0,8):
      if BitOrder == 'MSB': binary.append((item>>(8-1-i)) & 0x01)
      elif BitOrder == 'LSB': binary.append((item>>i) & 0x01)
      else: binary.append(0)
    
  if NRZ: binary = [1 if x==1 else -1 for x in binary]

  return binary

#----------------------------------------------------------------------------------------

def dec2bin(number, nbits):

  """
  Convert  data to binary representation
    - data = input data in decimal
    - nbits = binary length of output

    returns bits 
  """
  binary = []

  for i in range(0,nbits):
    binary.append(number>>(nbits-1-i)&1)
  
  return binary

#----------------------------------------------------------------------------------------

def CalculateCRC(bitstream, seed, poly):

    """
    calculate a CRC 
      - bitstream = ndarray of bits
      - seed = CRC seed, decimal or hexadecimal number
      - poly = polynomial coefficient as a tuple

      returns crc bits 
    """

    polynome = 1
    for coeff in poly: polynome += (1<<coeff)
    
    sequence=seed
    msbSeq = poly[0]-1 

    for bit in bitstream:

        if ((sequence>>msbSeq)&1) ^ ((np.int8(bit))&1) == 1:
            sequence = (sequence<<1) ^ polynome
        else:
            sequence = (sequence<<1)
    
    sequence  = [(sequence >> (msbSeq-1-i))&1 for i in range(msbSeq)]

    return sequence
  
#----------------------------------------------------------------------------------------

def decode_payload(payload, payloadSize):

  """
    decode payload  
      - payload = payload data as ndarray of bits
      - payloadSize = expected payload size in bytes

      returns string of bytes
  """

  if len(payload)%8 != 0:
    logging.info("The payload does not contain a multiple of 8 bits")
    return []
  
  else:
    payloadString = '0x'
    payloadBytes = []
    for i in range(0, payloadSize):
        octet = 0
        for j in range(0,8):
            octet += payload[i*8 + j] << int(7-j)
        payloadBytes.append(octet)

    payloadString += ''.join('{:02x}'.format(a) for a in payloadBytes)
  
    return payloadString

#========================================================================================
#========================================================================================