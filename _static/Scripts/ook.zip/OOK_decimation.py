#!/usr/bin/env python

"""
MIT License

Copyright (c) 2022 Yannish RAMGULAM

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import numpy as np
import scipy.signal
import matplotlib
matplotlib.use('tkAgg', force=True)
import matplotlib.pyplot as plt
from scipy.io import wavfile
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

if __name__ == "__main__":

    #  Constants
    DecimationRatio = 10

    # read wav_file
    Fs, data = wavfile.read('./keyfob_iq_ook_small.wav')
    data = data/np.amax(data)

    I_data = data[:,0]
    Q_data = data[:,1]

    # --- This is the original complex IQ stream
    complex_data = I_data + 1j*Q_data

    t = np.arange(len(complex_data))/Fs

    # calculate spectrum
    f, Pxx = scipy.signal.welch(complex_data, Fs, nperseg=512, return_onesided=False, scaling='spectrum', window='hanning')
    f = np.fft.fftshift(f)
    Pxx = np.fft.fftshift(Pxx)
    Pxx_dB = 10*np.log10(Pxx)

    # Decimate data to improve SNR and reduce computing load
    # We decimate by 10 i.e. 2e6/10 = 200kHz output bandwidth
    decimated_data = scipy.signal.decimate(complex_data, DecimationRatio, ftype='fir')

    # calculate spectrum of decimated data
    f_dec, Pdec = scipy.signal.welch(decimated_data, Fs/DecimationRatio, nperseg=512, return_onesided=False, scaling='spectrum', window='hanning')
    f_dec = np.fft.fftshift(f_dec)
    Pdec = np.fft.fftshift(Pdec)
    Pdec_dB = 10*np.log10(Pdec)

    # This is just for the sake of plotting, to show the difference
    # between original signal and decimated signal on the same scale
    interpolated_data = scipy.signal.resample_poly(decimated_data, DecimationRatio,1) 

    # --- Plot results

    SMALL_SIZE = 12
    MEDIUM_SIZE = 14
    BIGGER_SIZE = 16

    plt.rc('font', size=SMALL_SIZE)                 # controls default text sizes
    plt.rc('axes', titlesize=MEDIUM_SIZE)           # fontsize of the axes title
    plt.rc('axes', labelsize=MEDIUM_SIZE)           # fontsize of the x and y labels
    plt.rc('xtick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('ytick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
    plt.rc('legend', fontsize=SMALL_SIZE)           # legend fontsize
    plt.rc('figure', titlesize=BIGGER_SIZE)         # fontsize of the figure title
    plt.rc('lines', linewidth=1.5, markersize=6)    # line parameters

    fig, (ax1, ax2) = plt.subplots(2, 2, sharex=False)
    mng = plt.get_current_fig_manager()
    mng.window.state('zoomed')

    # Plot IQ
    t = np.arange(len(I_data))/Fs*1000
    ax1[0].plot(t, I_data+1, label='I (Fs=2Msps)')
    ax1[0].plot(t, Q_data-1, label='Q (Fs=2Msps)')
    t = np.arange(len(interpolated_data))/Fs*1000
    ax1[0].plot(t, np.real(interpolated_data)+1, label='I (Fs=0.2Msps)')
    ax1[0].plot(t, np.imag(interpolated_data)-1, label='Q (Fs=0.2Msps)')
    ax1[0].set_ylim(top=4)
    ax1[0].legend(ncol=2)
    ax1[0].set_xlabel('time [ms]')
    ax1[0].set_ylabel('Amplitude')
    ax1[0].set_title('IQ samples', c='blue')

    # Plot spectrum
    ax1[1].plot(f/1000, Pxx_dB, label='Original')
    ax1[1].plot(f_dec/1000, Pdec_dB, label='x10 decimation')
    ax1[1].set_xlabel('Frequency [kHz]')
    ax1[1].set_ylabel('Power [dB]')
    ax1[1].set_title('Power Spectrum', c='blue')
    ax1[1].legend()

    # Plot Enveloppe
    t = np.arange(len(complex_data))/Fs*1000 
    ax2[0].plot(t, np.abs(complex_data), label='Original')
    t = np.arange(len(interpolated_data))/Fs*1000 
    ax2[0].plot(t, np.abs(interpolated_data), label='x10 decimation')
    ax2[0].set_ylim(top=2)
    ax2[0].legend()
    ax2[0].set_xlabel('time [ms]')
    ax2[0].set_ylabel('Amplitude')
    ax2[0].set_title('Enveloppe', c='blue')

    fig.tight_layout()
    fig.subplots_adjust(wspace=0.15, hspace=0.35, bottom=0.08, top=0.9, left=0.06, right=0.97)

    plt.show()


