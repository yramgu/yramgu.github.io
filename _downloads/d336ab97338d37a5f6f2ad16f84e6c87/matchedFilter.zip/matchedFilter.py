#!/usr/bin/env python

import numpy as np
import scipy.signal
import matplotlib
matplotlib.use('tkAgg', force=True)
import matplotlib.pyplot as plt

from scipy.io import wavfile
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import time

# ------------------------------------------------------------------ 
#                       MAIN CODE
# ------------------------------------------------------------------

bitrate = 5000

# --- read wav_file
Fs, data = wavfile.read('./keyfob_iq_ook_small.wav')
data = data/np.amax(data)

I_data = data[:,0]
Q_data = data[:,1]

print("Sampling frequency Fs = %d MHz \n"%(Fs/1e6))

# --- This is the original complex IQ stream
complex_data = I_data + 1j*Q_data

# Extract enveloppe
Enveloppe = np.abs(complex_data)/np.sqrt(2)
t = np.arange(len(complex_data))/Fs

# slice original signal
threshold = 0.5
original_sliced = np.asarray([0 if x < threshold else 1 for x in Enveloppe])

# add some noise
noisyData = Enveloppe + np.random.randn(len(Enveloppe))

# Matched filtering
samples_per_bit = int(Fs/bitrate) # Calculate number of samples per bit
reference_pulse = np.repeat([1], samples_per_bit) # Create reference pulse of length "samples_per_bit"
matched_Data = scipy.signal.correlate(Enveloppe, reference_pulse, mode='same') / samples_per_bit # Correlate
matched_noisyData = scipy.signal.correlate(noisyData, reference_pulse, mode='same') / samples_per_bit # Correlate

# slice match filtered data
matched_sliced = np.asarray([0 if x < threshold else 1 for x in matched_Data])

# just for plotting purposes
refPulse = np.zeros(1)
refPulse = np.append(refPulse, reference_pulse)
refPulse = np.append(refPulse, np.zeros(1))

# ------------------------------------------------------------------ 
#                       PLOT RESULTS
# ------------------------------------------------------------------

SMALL_SIZE = 12
MEDIUM_SIZE = 14
BIGGER_SIZE = 16

plt.rc('font', size=SMALL_SIZE)                 # controls default text sizes
plt.rc('axes', titlesize=MEDIUM_SIZE)           # fontsize of the axes title
plt.rc('axes', labelsize=MEDIUM_SIZE)           # fontsize of the x and y labels
plt.rc('xtick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
plt.rc('ytick', labelsize=SMALL_SIZE)           # fontsize of the tick labels
plt.rc('legend', fontsize=SMALL_SIZE)           # legend fontsize
plt.rc('figure', titlesize=BIGGER_SIZE)         # fontsize of the figure title
plt.rc('lines', linewidth=1.5, markersize=6)    # line parameters

fig, (ax1, ax2) = plt.subplots(2, 2, sharex=False)
mng = plt.get_current_fig_manager()
mng.window.state('zoomed')

#--------------------------- AX1 -----------------------------------
ax1[0].plot(t, Enveloppe, label='Enveloppe')
ax1[0].plot(t, original_sliced + 1.2, label='sliced data')
ax1[0].plot(np.arange(len(refPulse))/Fs, refPulse+2.4, label='Reference Pulse')
""" ax1[0].legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3,
           ncol=1, mode=None, borderaxespad=0.) """
ax1[0].legend()
ax1[0].set_xlabel('time [ms]')
ax1[0].set_ylabel('Amplitude')
ax1[0].set_ylim(top=3.5)
ax1[0].set_title('Signal enveloppe', c='blue')

ax1[1].plot(t, noisyData, label='')
ax1[1].set_xlabel('time [ms]')
ax1[1].set_ylabel('Amplitude')
ax1[1].set_title('Noisy signal enveloppe', c='blue')

#--------------------------- AX2 -----------------------------------

ax2[0].plot(t, matched_Data, label='match-filtered data')
ax2[0].plot(t, matched_sliced, label='sliced data')
ax2[0].legend()
ax2[0].set_xlabel('time [ms]')
ax2[0].set_ylim(top=1.4)
ax2[0].set_ylabel('Amplitude')
ax2[0].set_title('sliced data   ', c='blue')

ax2[1].plot(t, matched_Data, label='From original signal')
ax2[1].plot(t, matched_noisyData, label='From Noisy Data')
""" ax2[1].legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3,
           ncol=2, mode=None, borderaxespad=0.) """
ax2[1].legend()
ax2[1].set_xlabel('time [ms]')
ax2[1].set_ylim(top=1.4)
ax2[1].set_ylabel('Amplitude')
ax2[1].set_title('match-filtered data', c='blue')

#-------------------------------------------------------------------

fig.tight_layout()
fig.subplots_adjust(wspace=0.1, hspace=0.3, bottom=0.08, top=0.95, left=0.06, right=0.95)

plt.show()


